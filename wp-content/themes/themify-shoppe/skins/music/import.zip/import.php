<?php

defined( 'ABSPATH' ) or die;

$GLOBALS['processed_terms'] = array();
$GLOBALS['processed_posts'] = array();

require_once ABSPATH . 'wp-admin/includes/post.php';
require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

/**
 * Add an Import Action, this data is stored for processing after import is done.
 *
 * Each action is sent as an Ajax request and is handled by themify-ajax.php file
 */ 
function themify_add_import_action( $action = '', $data = array() ) {
	global $import_actions;

	if ( ! isset( $import_actions[ $action ] ) ) {
		$import_actions[ $action ] = array();
	}

	$import_actions[ $action ][] = $data;
}

function themify_import_post( $post ) {
	global $processed_posts, $processed_terms;

	if ( ! post_type_exists( $post['post_type'] ) ) {
		return;
	}

	/* Menu items don't have reliable post_title, skip the post_exists check */
	if( $post['post_type'] !== 'nav_menu_item' ) {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
		if ( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
			$processed_posts[ intval( $post['ID'] ) ] = intval( $post_exists );
			return;
		}
	}

	if( $post['post_type'] == 'nav_menu_item' ) {
		if( ! isset( $post['tax_input']['nav_menu'] ) || ! term_exists( $post['tax_input']['nav_menu'], 'nav_menu' ) ) {
			return;
		}
		$_menu_item_type = $post['meta_input']['_menu_item_type'];
		$_menu_item_object_id = $post['meta_input']['_menu_item_object_id'];

		if ( 'taxonomy' == $_menu_item_type && isset( $processed_terms[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_terms[ intval( $_menu_item_object_id ) ];
		} else if ( 'post_type' == $_menu_item_type && isset( $processed_posts[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_posts[ intval( $_menu_item_object_id ) ];
		} else if ( 'custom' != $_menu_item_type ) {
			// associated object is missing or not imported yet, we'll retry later
			// $missing_menu_items[] = $item;
			return;
		}
	}

	$post_parent = ( $post['post_type'] == 'nav_menu_item' ) ? $post['meta_input']['_menu_item_menu_item_parent'] : (int) $post['post_parent'];
	$post['post_parent'] = 0;
	if ( $post_parent ) {
		// if we already know the parent, map it to the new local ID
		if ( isset( $processed_posts[ $post_parent ] ) ) {
			if( $post['post_type'] == 'nav_menu_item' ) {
				$post['meta_input']['_menu_item_menu_item_parent'] = $processed_posts[ $post_parent ];
			} else {
				$post['post_parent'] = $processed_posts[ $post_parent ];
			}
		}
	}

	/**
	 * for hierarchical taxonomies, IDs must be used so wp_set_post_terms can function properly
	 * convert term slugs to IDs for hierarchical taxonomies
	 */
	if( ! empty( $post['tax_input'] ) ) {
		foreach( $post['tax_input'] as $tax => $terms ) {
			if( is_taxonomy_hierarchical( $tax ) ) {
				$terms = explode( ', ', $terms );
				$post['tax_input'][ $tax ] = array_map( 'themify_get_term_id_by_slug', $terms, array_fill( 0, count( $terms ), $tax ) );
			}
		}
	}

	$post['post_author'] = (int) get_current_user_id();
	$post['post_status'] = 'publish';

	$old_id = $post['ID'];

	unset( $post['ID'] );
	$post_id = wp_insert_post( $post, true );
	if( is_wp_error( $post_id ) ) {
		return false;
	} else {
		$processed_posts[ $old_id ] = $post_id;

		return $post_id;
	}
}

function themify_get_placeholder_image() {
	static $placeholder_image = null;

	if ( $placeholder_image == null ) {
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;

		$post = array();

		$upload = wp_upload_bits( 'themify-placeholder.jpg', null, $wp_filesystem->get_contents( THEMIFY_DIR . '/img/image-placeholder.jpg' ) );

		if ( $info = wp_check_filetype( $upload['file'] ) )
			$post = array(
				'post_mime_type' => $info['type']
			);
		else
			return new WP_Error( 'attachment_processing_error', __( 'Invalid file type', 'themify' ) );

		$post['guid'] = $upload['url'];
		$placeholder_image = wp_insert_attachment( $post, $upload['file'] );
		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		wp_update_attachment_metadata( $placeholder_image, wp_generate_attachment_metadata( $placeholder_image, $upload['file'] ) );
	}

	return $placeholder_image;
}

function themify_import_term( $term ) {
	global $processed_terms;

	if( $term_id = term_exists( $term['slug'], $term['taxonomy'] ) ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];
		if ( isset( $term['term_id'] ) )
			$processed_terms[ intval( $term['term_id'] ) ] = (int) $term_id;
		return (int) $term_id;
	}

	if ( empty( $term['parent'] ) || ! isset( $processed_terms[ intval( $term['parent'] ) ] ) ) {
		$parent = 0;
	} else {
		$parent = term_exists( $processed_terms[ intval( $term['parent'] ) ], $term['taxonomy'] );
		if ( is_array( $parent ) ) $parent = $parent['term_id'];
	}

	$id = wp_insert_term( $term['name'], $term['taxonomy'], array(
		'parent' => $parent,
		'slug' => $term['slug'],
		'description' => $term['description'],
	) );
	if ( ! is_wp_error( $id ) ) {
		if ( isset( $term['term_id'] ) ) {
			// success!
			$processed_terms[ intval($term['term_id']) ] = $id['term_id'];
			if ( isset( $term['thumbnail'] ) ) {
				themify_add_import_action( 'term_thumb', array(
					'id' => $id['term_id'],
					'thumb' => $term['thumbnail'],
				) );
			}
			return $term['term_id'];
		}
	}

	return false;
}

function themify_get_term_id_by_slug( $slug, $tax ) {
	$term = get_term_by( 'slug', $slug, $tax );
	if( $term ) {
		return $term->term_id;
	}

	return false;
}

function themify_undo_import_term( $term ) {
	$term_id = term_exists( $term['slug'], $term['taxonomy'] );
	if ( $term_id ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];

		if ( $term_thumbnail = get_term_meta( $term['term_id'], 'thumbnail_id', true ) ) {
			wp_delete_attachment( $term_thumbnail, true );
		}

		if ( isset( $term_id ) ) {
			wp_delete_term( $term_id, $term['taxonomy'] );
		}
	}
}

/**
 * Determine if a post exists based on title, content, and date
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param array $args array of database parameters to check
 * @return int Post ID if post exists, 0 otherwise.
 */
function themify_post_exists( $args = array() ) {
	global $wpdb;

	$query = "SELECT ID FROM $wpdb->posts WHERE 1=1";
	$db_args = array();

	foreach ( $args as $key => $value ) {
		$value = wp_unslash( sanitize_post_field( $key, $value, 0, 'db' ) );
		if( ! empty( $value ) ) {
			$query .= ' AND ' . $key . ' = %s';
			$db_args[] = $value;
		}
	}

	if ( !empty ( $args ) )
		return (int) $wpdb->get_var( $wpdb->prepare($query, $args) );

	return 0;
}

function themify_undo_import_post( $post ) {
	if( $post['post_type'] == 'nav_menu_item' ) {
		$post_exists = themify_post_exists( array(
			'post_name' => $post['post_name'],
			'post_modified' => $post['post_date'],
			'post_type' => 'nav_menu_item',
		) );
	} else {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
	}
	if( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
		/**
		 * check if the post has been modified, if so leave it be
		 *
		 * NOTE: posts are imported using wp_insert_post() which modifies post_modified field
		 * to be the same as post_date, hence to check if the post has been modified,
		 * the post_modified field is compared against post_date in the original post.
		 */
		if( $post['post_date'] == get_post_field( 'post_modified', $post_exists ) ) {
			// find and remove all post attachments
			$attachments = get_posts( array(
				'post_type' => 'attachment',
				'posts_per_page' => -1,
				'post_parent' => $post_exists,
			) );
			if ( $attachments ) {
				foreach ( $attachments as $attachment ) {
					wp_delete_attachment( $attachment->ID, true );
				}
			}
			wp_delete_post( $post_exists, true ); // true: bypass trash
		}
	}
}

function themify_process_post_import( $post ) {
	if( ERASEDEMO ) {
		themify_undo_import_post( $post );
	} else {
		if ( $id = themify_import_post( $post ) ) {
			if ( defined( 'IMPORT_IMAGES' ) && ! IMPORT_IMAGES ) {
				/* if importing images is disabled and post is supposed to have a thumbnail, create a placeholder image instead */
				if ( isset( $post['thumb'] ) ) { // the post is supposed to have featured image
					$placeholder = themify_get_placeholder_image();
					if ( ! empty( $placeholder ) && ! is_wp_error( $placeholder ) ) {
						set_post_thumbnail( $id, $placeholder );
					}
				}
			} else {
				if ( isset( $post["thumb"] ) ) {
					themify_add_import_action( 'post_thumb', array(
						'id' => $id,
						'thumb' => $post["thumb"],
					) );
				}
				if ( isset( $post["gallery_shortcode"] ) ) {
					themify_add_import_action( 'gallery_field', array(
						'id' => $id,
						'fields' => $post["gallery_shortcode"],
					) );
				}
				if ( isset( $post["_product_image_gallery"] ) ) {
					themify_add_import_action( 'product_gallery', array(
						'id' => $id,
						'images' => $post["_product_image_gallery"],
					) );
				}
			}
		}
	}
}
$thumbs = array();
function themify_do_demo_import() {
global $import_actions;

	if ( isset( $GLOBALS["ThemifyBuilder_Data_Manager"] ) ) {
		remove_action( "save_post", array( $GLOBALS["ThemifyBuilder_Data_Manager"], "save_builder_text_only"), 10, 3 );
	}
$term = array (
  'term_id' => 24,
  'name' => 'Latest News',
  'slug' => 'latest-news',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 21,
  'name' => 'Icon Menu',
  'slug' => 'icon-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 22,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 23,
  'name' => 'Footer Support Menu',
  'slug' => 'footer-support-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$post = array (
  'ID' => 2625,
  'post_date' => '2017-03-14 10:01:58',
  'post_date_gmt' => '2017-03-14 10:01:58',
  'post_content' => 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.',
  'post_title' => 'Nemo enim Album',
  'post_excerpt' => '',
  'post_name' => 'nemo-enim-album',
  'post_modified' => '2017-04-21 13:31:21',
  'post_modified_gmt' => '2017-04-21 13:31:21',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2625',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"ltcd706\\"}],\\"styling\\":[],\\"element_id\\":\\"98ef901\\"}]',
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/PeopleImages.com-ID369973.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2623,
  'post_date' => '2017-03-14 05:01:05',
  'post_date_gmt' => '2017-03-14 05:01:05',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Sed do eiusmod Album',
  'post_excerpt' => '',
  'post_name' => 'sed-eiusmod-album',
  'post_modified' => '2017-04-21 13:20:48',
  'post_modified_gmt' => '2017-04-21 13:20:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2623',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"2b4n530\\"}],\\"styling\\":[],\\"element_id\\":\\"ik9k420\\"}]',
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/gitar-road-man.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2617,
  'post_date' => '2017-03-13 16:00:17',
  'post_date_gmt' => '2017-03-13 16:00:17',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_title' => 'Spotify acquires Album',
  'post_excerpt' => '',
  'post_name' => 'spotify-acquires-album',
  'post_modified' => '2017-04-21 13:31:35',
  'post_modified_gmt' => '2017-04-21 13:31:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2617',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"i8e2008\\"}],\\"styling\\":[],\\"element_id\\":\\"cc8t440\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/PeopleImages.com-ID1430835.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2659,
  'post_date' => '2017-03-13 10:34:16',
  'post_date_gmt' => '2017-03-13 10:34:16',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.',
  'post_title' => 'Halo Indonesia. Waktunya Spotify!',
  'post_excerpt' => '',
  'post_name' => 'halo-indonesia-waktunya-spotify',
  'post_modified' => '2017-04-21 13:14:32',
  'post_modified_gmt' => '2017-04-21 13:14:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2659',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"5zf9444\\"}],\\"styling\\":[],\\"element_id\\":\\"rim3032\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/PeopleImages-man-with-gitar.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2657,
  'post_date' => '2017-03-12 15:31:40',
  'post_date_gmt' => '2017-03-12 15:31:40',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Et harum quidem rerum facilis est et expedita distinctio.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Spotify now available on Amazon Echo',
  'post_excerpt' => '',
  'post_name' => 'spotify-now-available-amazon-echo',
  'post_modified' => '2017-04-21 13:41:14',
  'post_modified_gmt' => '2017-04-21 13:41:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2657',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"jqpb490\\"}],\\"styling\\":[],\\"element_id\\":\\"0n8u004\\"}]',
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/PeopleImages.com-ID457703.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2654,
  'post_date' => '2017-03-12 10:30:14',
  'post_date_gmt' => '2017-03-12 10:30:14',
  'post_content' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Work/Life Balance at Spotify',
  'post_excerpt' => '',
  'post_name' => 'worklife-balance-spotify',
  'post_modified' => '2017-04-21 13:09:33',
  'post_modified_gmt' => '2017-04-21 13:09:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2654',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"gbl1606\\"}],\\"styling\\":[],\\"element_id\\":\\"impf024\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/PeopleImages.com-ID452257.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2651,
  'post_date' => '2017-03-11 15:28:46',
  'post_date_gmt' => '2017-03-11 15:28:46',
  'post_content' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.',
  'post_title' => 'Ed Sheeran hits 500M streams',
  'post_excerpt' => '',
  'post_name' => 'ed-sheeran-hits-500m-streams',
  'post_modified' => '2017-04-21 13:26:27',
  'post_modified_gmt' => '2017-04-21 13:26:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2651',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"1szh555\\"}],\\"styling\\":[],\\"element_id\\":\\"7t1u505\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/omg-expression.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2647,
  'post_date' => '2017-03-11 10:28:01',
  'post_date_gmt' => '2017-03-11 10:28:01',
  'post_content' => 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
  'post_title' => 'Spotify and Chrome now play together',
  'post_excerpt' => '',
  'post_name' => 'spotify-chrome-now-play-together',
  'post_modified' => '2017-04-21 13:03:22',
  'post_modified_gmt' => '2017-04-21 13:03:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2647',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"iiff464\\"}],\\"styling\\":[],\\"element_id\\":\\"5n9t465\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/04/PeopleImages.com-ID436439.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2640,
  'post_date' => '2017-03-10 10:25:31',
  'post_date_gmt' => '2017-03-10 10:25:31',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => '$2 Billion and Counting',
  'post_excerpt' => '',
  'post_name' => '2-billion-counting',
  'post_modified' => '2017-04-21 13:08:57',
  'post_modified_gmt' => '2017-04-21 13:08:57',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?p=2640',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"vx4b440\\"}],\\"styling\\":[],\\"element_id\\":\\"1x0g152\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'category' => 'latest-news',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/playing-gitar.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2588,
  'post_date' => '2017-03-10 13:15:47',
  'post_date_gmt' => '2017-03-10 13:15:47',
  'post_content' => '<!--themify_builder_static--><h1>About Me</h1><h5>Hi I’m Angus Macrae talented musician &amp; producer.</h5>
<a href="#" > Buy my Album </a>
<h2>Hi I’m <a href="#">Angus Macrae</a> Talented Musician.</h2>
<h3>New single From Angus Macrae</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit.</p><p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper. Nulla in lectus non ante efficitur aliquet.<br />Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper.</p>
<h2>Music is My Passion<br />&amp; Everything</h2><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat.</p><p>[themify_col grid="2-1 first"][themify_list icon="fa-check" icon_color="#a97ae3"]</p><ul><li>Nam consectetur adipiscing</li><li>Consectetur adipisicing elit</li><li>Nemo enim ipsam voluptatem</li></ul><p>[/themify_list][/themify_col][themify_col grid="2-1"][themify_list icon="fa-check" icon_color="#a97ae3"]</p><ul><li>Sed do eiusmod tempor incididunt</li><li>Ut enim ad minima veniam</li><li>Excepteur sint occaecat cupidatat</li></ul><p>[/themify_list][/themify_col]</p>
<h2>Albums</h2>
<h2>Album Review</h2>
<ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2588-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Helpless</a> <audio id="audio-2588-2" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3?_=2" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">O Song</a> <audio id="audio-2588-3" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3?_=3" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Mystery Night</a> <audio id="audio-2588-4" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3?_=4" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Aggregate Mass</a> <audio id="audio-2588-5" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3?_=5" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Oniongrass</a> <audio id="audio-2588-6" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3?_=6" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3</a></audio> </li> </ol>

<img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1.jpg" alt="man-1" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1.jpg 601w, https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1-300x277.jpg 300w" sizes="(max-width: 601px) 100vw, 601px" />
<ul >
 
 <li data-product-id="2713"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/avenger/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-262x262.jpg" width="262" height="262" alt="album-7" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-262x262.jpg 262w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-768x768.jpg 768w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-58x58.jpg 58w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-40x40.jpg 40w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-500x500.jpg 500w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-47x48.jpg 47w, https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7.jpg 1000w" sizes="(max-width: 262px) 100vw, 262px" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/avenger/"> <h3>Avenger</h3> </a> &#36;30.90
 <a href="/demo/themes/shoppe-music/about/?add-to-cart=2713" data-quantity="1" data-product_id="2713" data-product_sku="" aria-label="Add &ldquo;Avenger&rdquo; to your cart" rel="nofollow">Add to cart</a> <a data-id="2713" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/avenger/?post_in_lightbox=1" rel="nofollow">Quick Look</a> </li>
 
 <li data-product-id="2717"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-262x262.jpg" width="262" height="262" alt="album-6" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-262x262.jpg 262w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-768x768.jpg 768w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-58x58.jpg 58w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-40x40.jpg 40w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-500x500.jpg 500w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-47x48.jpg 47w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6.jpg 1000w" sizes="(max-width: 262px) 100vw, 262px" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/"> <h3>Odesza In Return</h3> </a> &#36;25.50
 <a href="/demo/themes/shoppe-music/about/?add-to-cart=2717" data-quantity="1" data-product_id="2717" data-product_sku="" aria-label="Add &ldquo;Odesza In Return&rdquo; to your cart" rel="nofollow">Add to cart</a> <a data-id="2717" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/?post_in_lightbox=1" rel="nofollow">Quick Look</a> </li>
 
 <li data-product-id="2569"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-262x262.jpg" width="262" height="262" alt="album-1" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-262x262.jpg 262w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-768x768.jpg 768w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-58x58.jpg 58w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-40x40.jpg 40w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-500x500.jpg 500w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-47x48.jpg 47w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1.jpg 1000w" sizes="(max-width: 262px) 100vw, 262px" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/"> <h3>Black Beatles</h3> </a> &#36;25.90
 <a href="/demo/themes/shoppe-music/about/?add-to-cart=2569" data-quantity="1" data-product_id="2569" data-product_sku="" aria-label="Add &ldquo;Black Beatles&rdquo; to your cart" rel="nofollow">Add to cart</a> <a data-id="2569" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/?post_in_lightbox=1" rel="nofollow">Quick Look</a> </li>
 
 <li data-product-id="2568"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-262x262.jpg" width="262" height="262" alt="album-2" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-262x262.jpg 262w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-150x150.jpg 150w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-300x300.jpg 300w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-768x768.jpg 768w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-58x58.jpg 58w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-40x40.jpg 40w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-500x500.jpg 500w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-47x48.jpg 47w, https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2.jpg 1000w" sizes="(max-width: 262px) 100vw, 262px" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/"> <h3>Under the Iron Sea</h3> </a> &#36;26.90
 <a href="/demo/themes/shoppe-music/about/?add-to-cart=2568" data-quantity="1" data-product_id="2568" data-product_sku="" aria-label="Add &ldquo;Under the Iron Sea&rdquo; to your cart" rel="nofollow">Add to cart</a> <a data-id="2568" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/?post_in_lightbox=1" rel="nofollow">Quick Look</a> </li>
 
 </ul>
<a href="#" > Buy on itunes </a>
<h2>From the Blog.</h2>

<a href="#" > View All Articles </a><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2019-10-21 06:37:25',
  'post_modified_gmt' => '2019-10-21 06:37:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?page_id=2588',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'header_wrap' => 'transparent',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>About Me<\\\\/h1><h5>Hi I’m Angus Macrae talented musician &amp; producer.<\\\\/h5>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"80\\",\\"line_height_h1\\":\\"1\\",\\"line_height_h1_unit\\":\\"em\\",\\"h1_margin_bottom\\":\\"5\\",\\"font_size_h5\\":\\"18\\",\\"h5_margin_bottom\\":\\"35\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet_landscape\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"67\\"},\\"breakpoint_tablet\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"50\\"},\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"41\\"}},\\"element_id\\":\\"kiox028\\"},{\\"mod_name\\":\\"buttons\\",\\"mod_settings\\":{\\"buttons_size\\":\\"xlarge\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"Buy my Album\\",\\"link\\":\\"#\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"text_decoration\\":\\"none\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"hfxk598\\"}],\\"element_id\\":\\"y98l558\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/about-bg-1.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"22\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"15\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"17\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},\\"element_id\\":\\"4gpo055\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Hi I’m <a href=\\\\\\"#\\\\\\">Angus Macrae<\\\\/a> Talented Musician.<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"link_color\\":\\"a97ae3_1.00\\",\\"link_color_hover\\":\\"434789_1.00\\",\\"text_decoration\\":\\"none\\",\\"column_count\\":\\"1\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"48\\",\\"line_height_h2\\":\\"60\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"35\\",\\"line_height_h2\\":\\"50\\"}},\\"element_id\\":\\"sq4a035\\"}],\\"element_id\\":\\"67tt022\\"},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>New single From Angus Macrae<\\\\/h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat. Curabitur ultrices posuere bibendum. Ut a mi lorem. Nunc pulvinar ipsum vitae egestas suscipit.<\\\\/p><p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper. Nulla in lectus non ante efficitur aliquet.<br \\\\/>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec elementum turpis a lacinia semper.<\\\\/p>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_color_h3\\":\\"404040_1.00\\",\\"font_size_h3\\":\\"30\\",\\"line_height_h3\\":\\"48\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"9bb4767\\"}],\\"element_id\\":\\"uvb7596\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"nl7j059\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/04\\\\/man-with-gitar-1024x725.png\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"4524a8_0.61\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"1r40520\\"},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Music is My Passion<br \\\\/>&amp; Everything<\\\\/h2><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In sit amet mattis sapien. Mauris cursus tellus ut egestas maximus. Aliquam laoreet felis sed porta ultricies. Aliquam pulvinar erat ut tortor vulputate, et eleifend turpis eleifend. Nam sollicitudin bibendum tellus et consequat.<\\\\/p><p>[themify_col grid=\\\\\\"2-1 first\\\\\\"][themify_list icon=\\\\\\"fa-check\\\\\\" icon_color=\\\\\\"#a97ae3\\\\\\"]<\\\\/p><ul><li>Nam consectetur adipiscing<\\\\/li><li>Consectetur adipisicing elit<\\\\/li><li>Nemo enim ipsam voluptatem<\\\\/li><\\\\/ul><p>[\\\\/themify_list][\\\\/themify_col][themify_col grid=\\\\\\"2-1\\\\\\"][themify_list icon=\\\\\\"fa-check\\\\\\" icon_color=\\\\\\"#a97ae3\\\\\\"]<\\\\/p><ul><li>Sed do eiusmod tempor incididunt<\\\\/li><li>Ut enim ad minima veniam<\\\\/li><li>Excepteur sint occaecat cupidatat<\\\\/li><\\\\/ul><p>[\\\\/themify_list][\\\\/themify_col]<\\\\/p>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"font_color\\":\\"ffffff_1.00\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"48\\",\\"line_height_h2\\":\\"60\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"38\\",\\"line_height_h2\\":\\"50\\"}},\\"element_id\\":\\"5up3000\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_color\\":\\"434789_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"0\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"},\\"element_id\\":\\"mcgx127\\"}],\\"column_alignment\\":\\"col_align_middle\\",\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"5qll803\\"},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Albums<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"20\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"48\\",\\"line_height_h2\\":\\"60\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"38\\",\\"line_height_h2\\":\\"50\\"}},\\"element_id\\":\\"h3ek730\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Album Review<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"padding_left\\":\\"10\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"36\\",\\"h2_margin_top\\":\\"20\\",\\"h2_margin_bottom\\":\\"10\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"padding_top\\":\\"0\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"5\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"34\\"}},\\"element_id\\":\\"sag1532\\"},{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"},{\\"audio_name\\":\\"Helpless\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/Helpless.mp3\\"},{\\"audio_name\\":\\"O Song\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/o.mp3\\"},{\\"audio_name\\":\\"Mystery Night\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/db-Insom-Mystery-Night.mp3\\"},{\\"audio_name\\":\\"Aggregate Mass\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/crsh-grey_aggregate_mass.mp3\\"},{\\"audio_name\\":\\"Oniongrass\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/funk-oniongrass.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"wtm9577\\"},{\\"mod_name\\":\\"layout-part\\",\\"element_id\\":\\"h1k2450\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"28\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"15\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"15\\"},\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"15\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"10\\"}},\\"element_id\\":\\"xs4p050\\"},{\\"column_order\\":\\"1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/man-1.jpg\\",\\"param_image\\":\\"regular\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"dso7770\\"}],\\"element_id\\":\\"1roz037\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"custom_css_column\\":\\"shadow\\"},\\"element_id\\":\\"hs46820\\"}],\\"element_id\\":\\"tsrf203\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_repeat\\":\\"repeat\\",\\"background_position\\":\\"left-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"an6r523\\"},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"products\\",\\"mod_settings\\":{\\"query_products\\":\\"all\\",\\"category_products\\":\\"0|multiple\\",\\"hide_child_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"post_per_page_products\\":\\"4\\",\\"orderby_products\\":\\"date\\",\\"order_products\\":\\"desc\\",\\"template_products\\":\\"list\\",\\"layout_products\\":\\"grid4\\",\\"layout_slider\\":\\"slider-default\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"description_products\\":\\"none\\",\\"hide_feat_img_products\\":\\"no\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_rating_products\\":\\"no\\",\\"hide_sales_badge\\":\\"no\\",\\"hide_page_nav_products\\":\\"yes\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"jlcu002\\"},{\\"mod_name\\":\\"buttons\\",\\"mod_settings\\":{\\"buttons_size\\":\\"large\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"Buy on itunes\\",\\"link\\":\\"#\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"padding_top\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"q0oz702\\"}],\\"element_id\\":\\"n05r072\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"3\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_bottom_color\\":\\"dddddd_1.00\\",\\"border_bottom_width\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"wmxh012\\"},{\\"row_order\\":\\"5\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>From the Blog.<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"padding_bottom\\":\\"2\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"48\\",\\"line_height_h2\\":\\"60\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"c85x777\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid3\\",\\"post_type_post\\":\\"post\\",\\"content_layout\\":\\"polaroid\\",\\"masonry_post\\":\\"no\\",\\"type_query_post\\":\\"category\\",\\"category_post\\":\\"0|multiple\\",\\"post_tag_post\\":\\"0|multiple\\",\\"product_cat_post\\":\\"0|multiple\\",\\"product_tag_post\\":\\"0|multiple\\",\\"product_shipping_class_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"361\\",\\"img_height_post\\":\\"381\\",\\"hide_post_date_post\\":\\"no\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"blfs003\\"},{\\"mod_name\\":\\"buttons\\",\\"mod_settings\\":{\\"buttons_size\\":\\"large\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"View All Articles\\",\\"link\\":\\"#\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"25\\",\\"margin_bottom\\":\\"20\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"18tv353\\"}],\\"element_id\\":\\"7jyo350\\"}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"4\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"kbap352\\"},{\\"row_order\\":\\"6\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"element_id\\":\\"keov235\\"}],\\"element_id\\":\\"gbe5371\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2590,
  'post_date' => '2017-03-10 13:16:14',
  'post_date_gmt' => '2017-03-10 13:16:14',
  'post_content' => '<!--themify_builder_static--><h1>Latest Blog</h1>
<!--/themify_builder_static-->',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog-2',
  'post_modified' => '2019-10-22 08:04:28',
  'post_modified_gmt' => '2019-10-22 08:04:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?page_id=2590',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Latest Blog<\\\\/h1>\\",\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"text_align\\":\\"center\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"font_color_h1\\":\\"ffffff_1.00\\",\\"font_size_h1\\":\\"48\\",\\"line_height_h1\\":\\"60\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-type_image\\":\\"image\\",\\"background_image-type_gradient\\":\\"gradient\\",\\"background_image-gradient-type\\":\\"linear\\",\\"background_image-gradient-angle\\":\\"0\\",\\"font_family\\":\\"default\\",\\"font_size_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top_unit\\":\\"px\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom_unit\\":\\"px\\",\\"padding_left_unit\\":\\"px\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"border_top_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_style\\":\\"solid\\",\\"checkbox_border_apply_all\\":\\"|\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"font_family_h1\\":\\"default\\",\\"font_size_h1\\":\\"38\\",\\"font_size_h1_unit\\":\\"px\\",\\"line_height_h1\\":\\"50\\",\\"line_height_h1_unit\\":\\"px\\",\\"h1_margin_top_unit\\":\\"px\\",\\"h1_margin_bottom_unit\\":\\"px\\",\\"font_family_h2\\":\\"default\\",\\"font_size_h2_unit\\":\\"px\\",\\"line_height_h2_unit\\":\\"px\\",\\"h2_margin_top_unit\\":\\"px\\",\\"h2_margin_bottom_unit\\":\\"px\\",\\"font_family_h3\\":\\"default\\",\\"font_size_h3_unit\\":\\"px\\",\\"line_height_h3_unit\\":\\"px\\",\\"h3_margin_top_unit\\":\\"px\\",\\"h3_margin_bottom_unit\\":\\"px\\",\\"font_family_h4\\":\\"default\\",\\"font_size_h4_unit\\":\\"px\\",\\"line_height_h4_unit\\":\\"px\\",\\"h4_margin_top_unit\\":\\"px\\",\\"h4_margin_bottom_unit\\":\\"px\\",\\"font_family_h5\\":\\"default\\",\\"font_size_h5_unit\\":\\"px\\",\\"line_height_h5_unit\\":\\"px\\",\\"h5_margin_top_unit\\":\\"px\\",\\"h5_margin_bottom_unit\\":\\"px\\",\\"font_family_h6\\":\\"default\\",\\"font_size_h6_unit\\":\\"px\\",\\"line_height_h6_unit\\":\\"px\\",\\"h6_margin_top_unit\\":\\"px\\",\\"h6_margin_bottom_unit\\":\\"px\\"}},\\"element_id\\":\\"og5u208\\"}},\\"styling\\":[],\\"element_id\\":\\"8f9o802\\"}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/blog.jpg\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"background_gradient-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"6950d1_0.59\\",\\"cover_gradient-gradient-type\\":\\"linear\\",\\"cover_gradient-gradient-angle\\":\\"180\\",\\"cover_gradient-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"cover_gradient-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_gradient_hover-gradient-type\\":\\"linear\\",\\"cover_gradient_hover-gradient-angle\\":\\"180\\",\\"cover_gradient_hover-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"cover_gradient_hover-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"font_family\\":\\"default\\",\\"font_size_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top_unit\\":\\"%\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_style\\":\\"solid\\",\\"border_right_style\\":\\"solid\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_style\\":\\"solid\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"visibility_desktop\\":\\"show\\",\\"visibility_tablet\\":\\"show\\",\\"visibility_mobile\\":\\"show\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"background_slider\\":\\"\\",\\"background_slider_size\\":\\"\\",\\"background_slider_mode\\":\\"\\",\\"background_video\\":\\"\\",\\"background_image\\":\\"\\",\\"background_gradient-gradient-type\\":\\"linear\\",\\"background_gradient-gradient-angle\\":\\"180\\",\\"background_gradient-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"background_gradient-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"background_repeat\\":\\"\\",\\"background_position\\":\\"\\",\\"background_color\\":\\"\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"\\",\\"cover_gradient-gradient-type\\":\\"linear\\",\\"cover_gradient-gradient-angle\\":\\"180\\",\\"cover_gradient-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"cover_gradient-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color_hover\\":\\"\\",\\"cover_gradient_hover-gradient-type\\":\\"linear\\",\\"cover_gradient_hover-gradient-angle\\":\\"180\\",\\"cover_gradient_hover-gradient\\":\\"0% rgb(0, 0, 0)|100% rgb(255, 255, 255)\\",\\"cover_gradient_hover-css\\":\\"background-image: -moz-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -webkit-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -o-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: -ms-linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\nbackground-image: linear-gradient(180deg,rgb(0, 0, 0) 0%, rgb(255, 255, 255) 100%);\\\\r\\\\n\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"px\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"px\\",\\"text_align\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"\\",\\"padding_right_unit\\":\\"px\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"\\",\\"padding_left_unit\\":\\"px\\",\\"margin_top\\":\\"\\",\\"margin_top_unit\\":\\"px\\",\\"margin_right\\":\\"\\",\\"margin_right_unit\\":\\"px\\",\\"margin_bottom\\":\\"\\",\\"margin_bottom_unit\\":\\"px\\",\\"margin_left\\":\\"\\",\\"margin_left_unit\\":\\"px\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"solid\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"solid\\",\\"checkbox_border_apply_all\\":\\"border\\"}},\\"element_id\\":\\"cm9r417\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid3\\",\\"post_type_post\\":\\"post\\",\\"content_layout\\":\\"polaroid\\",\\"masonry_post\\":\\"no\\",\\"type_query_post\\":\\"category\\",\\"category_post\\":\\"0|multiple\\",\\"post_tag_post\\":\\"0|multiple\\",\\"product_cat_post\\":\\"0|multiple\\",\\"product_tag_post\\":\\"0|multiple\\",\\"product_shipping_class_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"9\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"361\\",\\"img_height_post\\":\\"381\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"buq3595\\"}},\\"styling\\":[],\\"element_id\\":\\"xqr4099\\"}],\\"column_alignment\\":\\"\\",\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_type\\":\\"image\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/blog-background.png\\",\\"background_repeat\\":\\"repeat-none\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"element_id\\":\\"iu1d050\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"y4a0606\\"}],\\"styling\\":[],\\"element_id\\":\\"hsb9189\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2581,
  'post_date' => '2017-03-10 13:10:28',
  'post_date_gmt' => '2017-03-10 13:10:28',
  'post_content' => '[woocommerce_cart]',
  'post_title' => 'Cart',
  'post_excerpt' => '',
  'post_name' => 'cart',
  'post_modified' => '2017-03-10 13:10:28',
  'post_modified_gmt' => '2017-03-10 13:10:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/cart/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2582,
  'post_date' => '2017-03-10 13:10:28',
  'post_date_gmt' => '2017-03-10 13:10:28',
  'post_content' => '[woocommerce_checkout]',
  'post_title' => 'Checkout',
  'post_excerpt' => '',
  'post_name' => 'checkout',
  'post_modified' => '2017-03-10 13:10:28',
  'post_modified_gmt' => '2017-03-10 13:10:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/checkout/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2592,
  'post_date' => '2017-03-10 13:19:12',
  'post_date_gmt' => '2017-03-10 13:19:12',
  'post_content' => '<!--themify_builder_static--><h1>Contact</h1>
<h3>We love to hear from you, whether a complaint or a compliment. Get in touch now.</h3>
<form action="https://themify.me/demo/themes/shoppe-music/wp-admin/admin-ajax.php" id="contact-0--form" method="post"> <label for="contact-0--contact-name">Your Name </label> <input type="text" name="contact-name" placeholder="" id="contact-0--contact-name" value="" /> <label for="contact-0--contact-email">Your Email </label> <input type="text" name="contact-email" placeholder="" id="contact-0--contact-email" value="" /> <label for="contact-0--contact-subject">Subject </label> <input type="text" name="contact-subject" placeholder="" id="contact-0--contact-subject" value="" /> <label for="contact-0--contact-message">Message *</label> <textarea name="contact-message" placeholder="" id="contact-0--contact-message" rows="8" cols="45" required></textarea> <button type="submit"> Send </button> </form>
<h3> Office Address </h3> <p>Oplication Block Street, Block 36,<br />Mexico City, Mexico<br />804538</p>
<h3> Office Hours </h3> <p>MON - FRIDAY: 12 Noon to 9 PM<br />SAT - SUN: 14 Noon to 12 PM</p>
<h3> Contact </h3> <p>Support: <a href="tel:1-800-268-8866">1-800-268-8866</a><br />Email: <a href="mailto:support@shoppe.com">support@shoppe.com</a></p><!--/themify_builder_static-->',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2019-09-19 15:51:16',
  'post_modified_gmt' => '2019-09-19 15:51:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?page_id=2592',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"5s4s304\\",\\"cols\\":[{\\"element_id\\":\\"yjaj338\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"sk6s342\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Contact<\\\\/h1>\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_color_h1\\":\\"ffffff_1.00\\",\\"font_size_h1\\":\\"48\\",\\"line_height_h1\\":\\"60\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"38\\",\\"line_height_h1\\":\\"50\\"}}}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https://themify.me/demo/themes/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/contact.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"6950d1_0.59\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"dxu6319\\",\\"cols\\":[{\\"element_id\\":\\"xmso352\\",\\"grid_class\\":\\"col-full\\"}],\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"g1lk321\\",\\"cols\\":[{\\"element_id\\":\\"bibd355\\",\\"grid_class\\":\\"col4-3\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"srr6355\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>We love to hear from you, whether a complaint or a compliment. Get in touch now.<\\\\/h3>\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_h3\\":\\"30\\",\\"line_height_h3\\":\\"42\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h3\\":\\"25\\",\\"line_height_h3\\":\\"35\\"}}},{\\"mod_name\\":\\"contact\\",\\"element_id\\":\\"bg7p356\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_border_inputs_apply_all\\":\\"1\\",\\"checkbox_border_send_apply_all\\":\\"1\\",\\"checkbox_padding_success_message_apply_all\\":\\"1\\",\\"checkbox_margin_success_message_apply_all\\":\\"1\\",\\"checkbox_border_success_message_apply_all\\":\\"1\\",\\"checkbox_padding_error_message_apply_all\\":\\"1\\",\\"checkbox_margin_error_message_apply_all\\":\\"1\\",\\"checkbox_border_error_message_apply_all\\":\\"1\\",\\"layout_contact\\":\\"style1\\",\\"field_name_label\\":\\"Your Name\\",\\"field_email_label\\":\\"Your Email\\",\\"field_subject_label\\":\\"Subject\\",\\"field_subject_active\\":\\"yes\\",\\"field_message_label\\":\\"Message\\",\\"field_sendcopy_label\\":\\"Send a copy to myself\\",\\"field_send_label\\":\\"Send\\",\\"field_email_active\\":\\"yes\\",\\"field_name_active\\":\\"yes\\",\\"field_message_active\\":\\"yes\\",\\"field_send_align\\":\\"left\\",\\"field_sendcopy_active\\":\\"\\",\\"field_captcha_active\\":\\"\\",\\"field_subject_require\\":\\"\\",\\"field_email_require\\":\\"\\",\\"field_name_require\\":\\"\\",\\"contact_sent_from\\":\\"enable\\",\\"post_author\\":\\"\\",\\"send_to_admins\\":\\"true\\"}}],\\"grid_width\\":\\"63.8549\\"},{\\"element_id\\":\\"0iu0357\\",\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"qwd9357\\",\\"mod_settings\\":{\\"title_feature\\":\\"Office Address\\",\\"content_feature\\":\\"<p>Oplication Block Street, Block 36,<br \\\\/>Mexico City, Mexico<br \\\\/>804538<\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"icon\\",\\"icon_feature\\":\\"ti-location-arrow\\",\\"icon_color_feature\\":\\"434789_1.00\\",\\"link_options\\":\\"regular\\",\\"font_color\\":\\"808080_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_title\\":\\"404040_1.00\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"44\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet\\":{\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"30\\"},\\"circle_color_feature\\":\\"#de5d5d\\",\\"circle_stroke_feature\\":\\"3\\",\\"circle_percentage_feature\\":\\"0\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"arez358\\",\\"mod_settings\\":{\\"title_feature\\":\\"Office Hours\\",\\"content_feature\\":\\"<p>MON - FRIDAY: 12 Noon to 9 PM<br \\\\/>SAT - SUN: 14 Noon to 12 PM<\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"icon\\",\\"icon_feature\\":\\"ti-time\\",\\"icon_color_feature\\":\\"434789_1.00\\",\\"link_options\\":\\"regular\\",\\"font_color\\":\\"808080_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_title\\":\\"404040_1.00\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"44\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet\\":{\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"30\\"},\\"circle_color_feature\\":\\"#de5d5d\\",\\"circle_stroke_feature\\":\\"3\\",\\"circle_percentage_feature\\":\\"0\\"}},{\\"mod_name\\":\\"feature\\",\\"element_id\\":\\"pzia359\\",\\"mod_settings\\":{\\"title_feature\\":\\"Contact\\",\\"content_feature\\":\\"<p>Support: <a href=\\\\\\\\\\\\\\"tel:1-800-268-8866\\\\\\\\\\\\\\">1-800-268-8866<\\\\/a><br \\\\/>Email: <a href=\\\\\\\\\\\\\\"mailto:support@shoppe.com\\\\\\\\\\\\\\">support@shoppe.com<\\\\/a><\\\\/p>\\",\\"layout_feature\\":\\"icon-left\\",\\"circle_size_feature\\":\\"small\\",\\"icon_type_feature\\":\\"icon\\",\\"icon_feature\\":\\"ti-email\\",\\"icon_color_feature\\":\\"434789_1.00\\",\\"link_options\\":\\"regular\\",\\"font_color\\":\\"808080_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_title\\":\\"404040_1.00\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"44\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet\\":{\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_title\\":\\"24\\",\\"line_height_title\\":\\"30\\"},\\"circle_color_feature\\":\\"#de5d5d\\",\\"circle_stroke_feature\\":\\"3\\",\\"circle_percentage_feature\\":\\"0\\"}}],\\"grid_width\\":\\"32.9454\\",\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"border_left_color\\":\\"e3e3e3_1.00\\",\\"border_left_width\\":\\"1\\",\\"custom_css_column\\":\\"contact-info\\",\\"breakpoint_mobile\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"border_left_color\\":\\"ffffff_1.00\\",\\"border_left_width\\":\\"1\\"}}}],\\"styling\\":{\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"6\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2551,
  'post_date' => '2017-03-10 12:24:14',
  'post_date_gmt' => '2017-03-10 12:24:14',
  'post_content' => '<!--themify_builder_static--><h1>Angus Macrae New Album</h1><h5>Choose your music by genre, workout type, BPM, and more.</h5>
<a href="https://themify.me/demo/themes/shoppe-music/shop/" > Shop Now </a>
<img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-with-gitar-900x630.png" width="900" alt="man-with-gitar" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-with-gitar-900x630.png 900w, https://themify.me/demo/themes/shoppe-music/files/2017/03/man-with-gitar-300x210.png 300w, https://themify.me/demo/themes/shoppe-music/files/2017/03/man-with-gitar-768x538.png 768w, https://themify.me/demo/themes/shoppe-music/files/2017/03/man-with-gitar.png 954w" sizes="(max-width: 900px) 100vw, 900px" />
<img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/record-disk-600x480.png" width="600" height="480" alt="record-disk" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/record-disk.png 600w, https://themify.me/demo/themes/shoppe-music/files/2017/03/record-disk-300x240.png 300w, https://themify.me/demo/themes/shoppe-music/files/2017/03/record-disk-200x160.png 200w" sizes="(max-width: 600px) 100vw, 600px" />

<h2>Out Now</h2><h5>New single From Angus Macrae</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do enim ad eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut minim veniam, quis nostrud exercitation ullamco laboris.</p>
<ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Helpless</a> <audio id="audio-0-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3?_=1" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3</a></audio> </li> </ol>
<h2>Album Review</h2>
<ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Helpless</a> <audio id="audio-0-2" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3?_=2" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/Helpless.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">O Song</a> <audio id="audio-0-3" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3?_=3" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/o.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Mystery Night</a> <audio id="audio-0-4" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3?_=4" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/db-Insom-Mystery-Night.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Aggregate Mass</a> <audio id="audio-0-5" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3?_=5" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/crsh-grey_aggregate_mass.mp3</a></audio> </li> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">Oniongrass</a> <audio id="audio-0-6" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3?_=6" /><a href="https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3">https://themify.me/demo/themes/addon-audio/files/2015/06/funk-oniongrass.mp3</a></audio> </li> </ol>
<img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1.jpg" alt="man-1" srcset="https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1.jpg 601w, https://themify.me/demo/themes/shoppe-music/files/2017/03/man-1-300x277.jpg 300w" sizes="(max-width: 601px) 100vw, 601px" />
<h2>Recent Albums</h2>
<ul data-width="260" data-height="245">
 <li data-product-id="2713"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/avenger/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7-260x245.jpg" width="260" height="245" alt="album-7" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/avenger/"> <h3>Avenger</h3> </a> &#36;30.90
 <a href="?add-to-cart=2713" data-quantity="1" data-product_id="2713" data-product_sku="" aria-label="Add &ldquo;Avenger&rdquo; to your cart" rel="nofollow">Add to cart</a>[<a href="https://themify.me/demo/themes/shoppe-music/wp-admin/post.php?post=2713&#038;action=edit">Edit</a>] <a data-id="2713" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/avenger/?post_in_lightbox=1" rel="nofollow">Quick Look</a> <a href="javascript:void(0);"></a> <a onclick="window.open(\'//twitter.com/intent/tweet?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Favenger&#038;text=Avenger\',\'twitter\',\'toolbar=0, status=0, width=650, height=360\')" title="Twitter" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Favenger&#038;t=Avenger&#038;original_referer=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Favenger%2F\',\'facebook\',\'toolbar=0, status=0, width=900, height=500\')" title="Facebook" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//pinterest.com/pin/create/button/?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Favenger&#038;description=Avenger&#038;media=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Ffiles%2F2017%2F05%2Falbum-7.jpg\',\'pinterest\',\'toolbar=no,width=700,height=300\')" title="Pinterest" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//www.linkedin.com/cws/share?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Favenger&#038;token=&#038;isFramed=true\',\'linkedin\',\'toolbar=no,width=550,height=550\')" title="LinkedIn" rel="nofollow" href="javascript:void(0);"></a> 
 </li>
 <li data-product-id="2717"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6-260x245.jpg" width="260" height="245" alt="album-6" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/"> <h3>Odesza In Return</h3> </a> &#36;25.50
 <a href="?add-to-cart=2717" data-quantity="1" data-product_id="2717" data-product_sku="" aria-label="Add &ldquo;Odesza In Return&rdquo; to your cart" rel="nofollow">Add to cart</a>[<a href="https://themify.me/demo/themes/shoppe-music/wp-admin/post.php?post=2717&#038;action=edit">Edit</a>] <a data-id="2717" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/odesza-in-return/?post_in_lightbox=1" rel="nofollow">Quick Look</a> <a href="javascript:void(0);"></a> <a onclick="window.open(\'//twitter.com/intent/tweet?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fodesza-in-return&#038;text=Odesza+In+Return\',\'twitter\',\'toolbar=0, status=0, width=650, height=360\')" title="Twitter" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fodesza-in-return&#038;t=Odesza+In+Return&#038;original_referer=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fodesza-in-return%2F\',\'facebook\',\'toolbar=0, status=0, width=900, height=500\')" title="Facebook" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//pinterest.com/pin/create/button/?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fodesza-in-return&#038;description=Odesza+In+Return&#038;media=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Ffiles%2F2017%2F03%2Falbum-6.jpg\',\'pinterest\',\'toolbar=no,width=700,height=300\')" title="Pinterest" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//www.linkedin.com/cws/share?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fodesza-in-return&#038;token=&#038;isFramed=true\',\'linkedin\',\'toolbar=no,width=550,height=550\')" title="LinkedIn" rel="nofollow" href="javascript:void(0);"></a> 
 </li>
 <li data-product-id="2569"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1-260x245.jpg" width="260" height="245" alt="album-1" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/"> <h3>Black Beatles</h3> </a> &#36;25.90
 <a href="?add-to-cart=2569" data-quantity="1" data-product_id="2569" data-product_sku="" aria-label="Add &ldquo;Black Beatles&rdquo; to your cart" rel="nofollow">Add to cart</a>[<a href="https://themify.me/demo/themes/shoppe-music/wp-admin/post.php?post=2569&#038;action=edit">Edit</a>] <a data-id="2569" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/black-beatles/?post_in_lightbox=1" rel="nofollow">Quick Look</a> <a href="javascript:void(0);"></a> <a onclick="window.open(\'//twitter.com/intent/tweet?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fblack-beatles&#038;text=Black+Beatles\',\'twitter\',\'toolbar=0, status=0, width=650, height=360\')" title="Twitter" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fblack-beatles&#038;t=Black+Beatles&#038;original_referer=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fblack-beatles%2F\',\'facebook\',\'toolbar=0, status=0, width=900, height=500\')" title="Facebook" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//pinterest.com/pin/create/button/?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fblack-beatles&#038;description=Black+Beatles&#038;media=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Ffiles%2F2017%2F03%2Falbum-1.jpg\',\'pinterest\',\'toolbar=no,width=700,height=300\')" title="Pinterest" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//www.linkedin.com/cws/share?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Fblack-beatles&#038;token=&#038;isFramed=true\',\'linkedin\',\'toolbar=no,width=550,height=550\')" title="LinkedIn" rel="nofollow" href="javascript:void(0);"></a> 
 </li>
 <li data-product-id="2568"> <figure ><a href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/"><img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2-260x245.jpg" width="260" height="245" alt="album-2" /></a></figure> <a href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/"> <h3>Under the Iron Sea</h3> </a> &#36;26.90
 <a href="?add-to-cart=2568" data-quantity="1" data-product_id="2568" data-product_sku="" aria-label="Add &ldquo;Under the Iron Sea&rdquo; to your cart" rel="nofollow">Add to cart</a>[<a href="https://themify.me/demo/themes/shoppe-music/wp-admin/post.php?post=2568&#038;action=edit">Edit</a>] <a data-id="2568" onclick="javascript:void(0)" href="#" rel="nofollow"> Wishlist </a> <a onclick="return false;" data-image="https://themify.me/demo/themes/shoppe-music/files/woocommerce-placeholder.png" href="https://themify.me/demo/themes/shoppe-music/product/under-the-iron-sea/?post_in_lightbox=1" rel="nofollow">Quick Look</a> <a href="javascript:void(0);"></a> <a onclick="window.open(\'//twitter.com/intent/tweet?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Funder-the-iron-sea&#038;text=Under+the+Iron+Sea\',\'twitter\',\'toolbar=0, status=0, width=650, height=360\')" title="Twitter" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Funder-the-iron-sea&#038;t=Under+the+Iron+Sea&#038;original_referer=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Funder-the-iron-sea%2F\',\'facebook\',\'toolbar=0, status=0, width=900, height=500\')" title="Facebook" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//pinterest.com/pin/create/button/?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Funder-the-iron-sea&#038;description=Under+the+Iron+Sea&#038;media=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Ffiles%2F2017%2F03%2Falbum-2.jpg\',\'pinterest\',\'toolbar=no,width=700,height=300\')" title="Pinterest" rel="nofollow" href="javascript:void(0);"></a> <a onclick="window.open(\'//www.linkedin.com/cws/share?url=https%3A%2F%2Fthemify.me%2Fdemo%2Fthemes%2Fshoppe-music%2Fproduct%2Funder-the-iron-sea&#038;token=&#038;isFramed=true\',\'linkedin\',\'toolbar=no,width=550,height=550\')" title="LinkedIn" rel="nofollow" href="javascript:void(0);"></a> 
 </li>
 </ul>
<a href="https://themify.me/demo/themes/shoppe-music/shop/" > View All </a>
<img src="https://themify.me/demo/themes/shoppe-music/files/2017/03/volumn-icon.png" alt="volumn-icon" />
<h2>The Audio module is simple<br />and easy to set-up</h2><h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sit amet mi mi. Nullam id mi ut.</h5>
<a href="https://themify.me/themes/shoppe" > Buy album now </a>
<img src="https://themify.me/demo/themes/shoppe-music/files/2017/05/itune-button-166x48.png" width="166" alt="itune-button" /><!--/themify_builder_static-->',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-06-10 05:59:46',
  'post_modified_gmt' => '2020-06-10 05:59:46',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?page_id=2551',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'header_wrap' => 'transparent',
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"9zgs658\\",\\"cols\\":[{\\"element_id\\":\\"5uvk661\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"akua662\\",\\"cols\\":[{\\"element_id\\":\\"qc8p662\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"5bg0663\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Angus Macrae New Album<\\\\/h1><h5>Choose your music by genre, workout type, BPM, and more.<\\\\/h5>\\",\\"background_image-type\\":\\"image\\",\\"font_color\\":\\"ffffff_1.00\\",\\"column_count\\":\\"1\\",\\"padding_top\\":\\"0\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"font_size_h1\\":\\"71\\",\\"line_height_h1\\":\\"1\\",\\"line_height_h1_unit\\":\\"em\\",\\"h1_margin_bottom\\":\\"25\\",\\"font_size_h5\\":\\"18\\",\\"h5_margin_bottom\\":\\"35\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet_landscape\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"50\\",\\"h1_margin_bottom\\":\\"20\\"},\\"breakpoint_tablet\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"45\\",\\"h1_margin_bottom\\":\\"15\\"},\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h1\\":\\"41\\"}}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"c09y664\\",\\"mod_settings\\":{\\"buttons_size\\":\\"xlarge\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"Shop Now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"padding_bottom\\":\\"8\\",\\"padding_bottom_unit\\":\\"em\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"link_checkbox_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"padding_bottom\\":\\"2\\",\\"padding_bottom_unit\\":\\"em\\",\\"margin_bottom_unit\\":\\"em\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\"}}}],\\"grid_width\\":38.2556000000000011596057447604835033416748046875,\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"padding_left\\":\\"0\\",\\"padding_left_unit\\":\\"%\\",\\"breakpoint_tablet_landscape\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left_unit\\":\\"%\\"},\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left_unit\\":\\"%\\"},\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left\\":\\"0\\"}}},{\\"element_id\\":\\"h1wk664\\",\\"grid_class\\":\\"col3-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3zww664\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/man-with-gitar-900x630.png\\",\\"param_image\\":\\"regular\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"background_image-type\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"-4.3\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_left\\":\\"-1\\",\\"margin_left_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"-4.2\\",\\"margin_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet_landscape\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_left\\":\\"0\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_bottom\\":\\"-4\\",\\"margin_bottom_unit\\":\\"%\\",\\"margin_left\\":\\"0\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"image_zoom_icon\\":false,\\"lightbox_height_unit\\":\\"px\\",\\"lightbox_width_unit\\":\\"px\\",\\"auto_fullwidth\\":false,\\"width_image\\":\\"900\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}],\\"grid_width\\":61.7443999999999988403942552395164966583251953125,\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-bottom\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"custom_css_column\\":\\"banner-img\\",\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_right\\":\\"15\\",\\"padding_left\\":\\"15\\"}}}],\\"column_alignment\\":\\"col_align_bottom\\",\\"gutter\\":\\"gutter-none\\",\\"col_mobile\\":\\"mobile-full\\"}]}],\\"col_tablet\\":\\"tablet-full\\",\\"col_mobile\\":\\"mobile-full\\",\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/hero-banner-bg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"9\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"breakpoint_tablet_landscape\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"7\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"9\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"},\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}},{\\"element_id\\":\\"m2go658\\",\\"cols\\":[{\\"element_id\\":\\"g1ia665\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"nftr665\\",\\"cols\\":[{\\"element_id\\":\\"a20g666\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"jdc9666\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/record-disk.png\\",\\"param_image\\":\\"regular\\",\\"background_image-type\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"width_image\\":\\"600\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false,\\"height_image\\":\\"480\\"}},{\\"mod_name\\":\\"layout-part\\",\\"element_id\\":\\"2jhh666\\"}]},{\\"element_id\\":\\"qj21666\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"th9c666\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Out Now<\\\\/h2><h5>New single From Angus Macrae<\\\\/h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do enim ad eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut minim veniam, quis nostrud exercitation ullamco laboris.<\\\\/p>\\",\\"background_image-type\\":\\"image\\",\\"font_color\\":\\"808080_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"72\\",\\"h2_margin_bottom\\":\\"0\\",\\"font_color_h5\\":\\"333333_1.00\\",\\"font_size_h5\\":\\"18\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_tablet\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"50\\"},\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"42\\"}}},{\\"mod_name\\":\\"audio\\",\\"element_id\\":\\"rmrq667\\",\\"mod_settings\\":{\\"background_color\\":\\"ffffff\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"breakpoint_tablet\\":{\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"15\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"15\\",\\"margin_bottom\\":\\"20\\"},\\"breakpoint_mobile\\":{\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"10\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"15\\"},\\"music_playlist\\":[{\\"audio_name\\":\\"Helpless\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/Helpless.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"out-now-audio\\",\\"animation_effect\\":\\"fadeInRight\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_left\\":\\"7\\",\\"padding_left_unit\\":\\"%\\",\\"breakpoint_tablet_landscape\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_bottom\\":\\"20\\"},\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"0\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"0\\"},\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"0\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"0\\"}}}],\\"column_alignment\\":\\"col_align_middle\\"},{\\"element_id\\":\\"lezt667\\",\\"cols\\":[{\\"element_id\\":\\"8n63667\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"tnmx667\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Album Review<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"padding_left\\":\\"10\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"36\\",\\"h2_margin_top\\":\\"20\\",\\"h2_margin_bottom\\":\\"10\\",\\"animation_effect\\":\\"fadeInLeft\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"padding_top\\":\\"0\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"5\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"34\\"}}},{\\"mod_name\\":\\"audio\\",\\"element_id\\":\\"wi8r668\\",\\"mod_settings\\":{\\"checkbox_padding_apply_all\\":\\"1\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"music_playlist\\":[{\\"audio_name\\":\\"Helpless\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/Helpless.mp3\\"},{\\"audio_name\\":\\"O Song\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/o.mp3\\"},{\\"audio_name\\":\\"Mystery Night\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/db-Insom-Mystery-Night.mp3\\"},{\\"audio_name\\":\\"Aggregate Mass\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/crsh-grey_aggregate_mass.mp3\\"},{\\"audio_name\\":\\"Oniongrass\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/addon-audio\\\\/files\\\\/2015\\\\/06\\\\/funk-oniongrass.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"animation_effect\\":\\"fadeInLeft\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"0\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"28\\",\\"breakpoint_tablet\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"15\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"15\\"},\\"breakpoint_mobile\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"15\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"10\\"}}},{\\"element_id\\":\\"5mky668\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"sfek668\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/man-1.jpg\\",\\"param_image\\":\\"regular\\",\\"background_image-type\\":\\"image\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"animation_effect\\":\\"fadeInRight\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\"}}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_color\\":\\"ffffff_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"custom_css_column\\":\\"shadow\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"cinl668\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Recent Albums<\\\\/h2>\\",\\"background_image-type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"padding_top\\":\\"7\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"434789_1.00\\",\\"font_size_h2\\":\\"50\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"39\\"}}},{\\"mod_name\\":\\"products\\",\\"element_id\\":\\"pjuw669\\",\\"mod_settings\\":{\\"query_products\\":\\"all\\",\\"category_products\\":\\"0|multiple\\",\\"hide_child_products\\":\\"no\\",\\"hide_free_products\\":\\"no\\",\\"post_per_page_products\\":\\"4\\",\\"orderby_products\\":\\"date\\",\\"order_products\\":\\"desc\\",\\"template_products\\":\\"list\\",\\"layout_products\\":\\"grid4\\",\\"masonry_post\\":\\"no\\",\\"disable_product_slider\\":\\"enable\\",\\"layout_slider\\":\\"slider-default\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"description_products\\":\\"none\\",\\"hide_feat_img_products\\":\\"no\\",\\"img_width_products\\":\\"260\\",\\"img_height_products\\":\\"245\\",\\"unlink_feat_img_products\\":\\"no\\",\\"hide_post_title_products\\":\\"no\\",\\"unlink_post_title_products\\":\\"no\\",\\"hide_price_products\\":\\"no\\",\\"hide_add_to_cart_products\\":\\"no\\",\\"hide_rating_products\\":\\"no\\",\\"hide_sales_badge\\":\\"no\\",\\"hide_page_nav_products\\":\\"yes\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"76i3669\\",\\"mod_settings\\":{\\"buttons_size\\":\\"xlarge\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"View All\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/shop\\\\/\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"background_image-type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"padding_top\\":\\"3\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"7\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_link_padding_apply_all\\":\\"padding\\",\\"link_checkbox_margin_apply_all\\":\\"margin\\",\\"link_checkbox_border_apply_all\\":\\"border\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"styling\\":{\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/musicbg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"margin_top\\":\\"5\\",\\"margin_top_unit\\":\\"%\\",\\"margin_bottom\\":\\"0\\",\\"margin_bottom_unit\\":\\"%\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"3sf7658\\",\\"cols\\":[{\\"element_id\\":\\"619n669\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"li7r669\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/volumn-icon.png\\",\\"param_image\\":\\"regular\\",\\"background_image-type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"padding_bottom\\":\\"33\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"6xne669\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>The Audio module is simple<br \\\\/>and easy to set-up<\\\\/h2><h5>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sit amet mi mi. Nullam id mi ut.<\\\\/h5>\\",\\"background_image-type\\":\\"image\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_color_h2\\":\\"ffffff_1.00\\",\\"font_size_h2\\":\\"48\\",\\"line_height_h2\\":\\"48\\",\\"font_color_h5\\":\\"ffffff_1.00\\",\\"font_size_h5\\":\\"16\\",\\"animation_effect\\":\\"fadeInUp\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"breakpoint_mobile\\":{\\"background_image-type\\":\\"image\\",\\"background_image-gradient-angle\\":\\"0\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"font_size_h2\\":\\"35\\",\\"line_height_h2\\":\\"42\\"}}},{\\"element_id\\":\\"qd1l670\\",\\"cols\\":[{\\"element_id\\":\\"o89e670\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"75nu670\\",\\"mod_settings\\":{\\"background_image-type\\":\\"image\\",\\"background_repeat\\":\\"repeat\\",\\"text_align\\":\\"right\\",\\"checkbox_padding_apply_all\\":\\"1\\",\\"margin_top\\":\\"30\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"checkbox_padding_link_apply_all\\":\\"1\\",\\"checkbox_link_margin_apply_all\\":\\"1\\",\\"checkbox_link_border_apply_all\\":\\"1\\",\\"buttons_size\\":\\"xlarge\\",\\"buttons_style\\":\\"squared\\",\\"content_button\\":[{\\"label\\":\\"Buy album now\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/themes\\\\/shoppe\\",\\"link_options\\":\\"regular\\",\\"button_color_bg\\":\\"blue\\"}],\\"css_button\\":\\"buy-button\\",\\"animation_effect\\":\\"fadeInUp\\"}}]},{\\"element_id\\":\\"3j3j670\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"y9c4670\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/05\\\\/itune-button-166x48.png\\",\\"param_image\\":\\"regular\\",\\"margin_top\\":\\"30\\",\\"image_zoom_icon\\":false,\\"auto_fullwidth\\":false,\\"width_image\\":\\"166\\",\\"appearance_image\\":false,\\"caption_on_overlay\\":false}}]}],\\"gutter\\":\\"gutter-narrow\\"}]}],\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_type\\":\\"image\\",\\"background_slider_size\\":\\"thumbnail\\",\\"background_slider_mode\\":\\"best-fit\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/background.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-top\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"4\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2583,
  'post_date' => '2017-03-10 13:10:28',
  'post_date_gmt' => '2017-03-10 13:10:28',
  'post_content' => '[woocommerce_my_account]',
  'post_title' => 'My Account',
  'post_excerpt' => '',
  'post_name' => 'my-account',
  'post_modified' => '2017-03-10 13:10:28',
  'post_modified_gmt' => '2017-03-10 13:10:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/my-account/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2580,
  'post_date' => '2017-03-10 13:10:28',
  'post_date_gmt' => '2017-03-10 13:10:28',
  'post_content' => '',
  'post_title' => 'Shop',
  'post_excerpt' => '',
  'post_name' => 'shop',
  'post_modified' => '2017-03-10 13:10:28',
  'post_modified_gmt' => '2017-03-10 13:10:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/shop/',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2702,
  'post_date' => '2017-04-21 18:33:10',
  'post_date_gmt' => '2017-04-21 18:33:10',
  'post_content' => '',
  'post_title' => 'Wishlist',
  'post_excerpt' => '',
  'post_name' => 'wishlist',
  'post_modified' => '2017-04-21 18:33:16',
  'post_modified_gmt' => '2017-04-21 18:33:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?page_id=2702',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'product_query_type' => 'all',
    'product_archive_show_short' => 'excerpt',
    'product_hide_navigation' => 'no',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"zzr8780\\"}],\\"styling\\":[],\\"element_id\\":\\"a3t6700\\"}]',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2759,
  'post_date' => '2019-10-30 06:42:11',
  'post_date_gmt' => '2019-10-30 06:42:11',
  'post_content' => '',
  'post_title' => 'Optin Form',
  'post_excerpt' => '',
  'post_name' => 'optin-form',
  'post_modified' => '2019-10-31 12:18:33',
  'post_modified_gmt' => '2019-10-31 12:18:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?post_type=tbuilder_layout_part&#038;p=2759',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout_part',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"3ho9268\\",\\"cols\\":[{\\"element_id\\":\\"p733269\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"optin\\",\\"element_id\\":\\"gf5a892\\",\\"mod_settings\\":{\\"label_firstname\\":\\"First Name\\",\\"default_fname\\":\\"John\\",\\"label_lastname\\":\\"Last Name\\",\\"default_lname\\":\\"Doe\\",\\"label_submit\\":\\"Subscribe\\",\\"message\\":\\"<p>Post updated. <a href=\\\\\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/tbuilder-layout-part\\\\/optin-form\\\\/\\\\\\">View post<\\\\/a><\\\\/p><p><button class=\\\\\\"notice-dismiss\\\\\\" type=\\\\\\"button\\\\\\"><span class=\\\\\\"screen-reader-text\\\\\\">Dismiss this notice.<\\\\/span><\\\\/button><\\\\/p>\\",\\"layout\\":\\"tb_optin_horizontal\\",\\"gdpr_label\\":\\"I consent to my submitted data being collected and stored\\",\\"success_action\\":\\"s2\\",\\"lname_hide\\":\\"1\\",\\"fname_hide\\":\\"1\\",\\"mailchimp_list\\":\\"0f2a95e5de\\",\\"provider\\":\\"mailchimp\\",\\"bg_c_s\\":\\"#434789\\",\\"f_s_s_unit\\":\\"px\\",\\"f_s_s\\":\\"13\\"}}]}]}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2713,
  'post_date' => '2017-04-15 11:53:32',
  'post_date_gmt' => '2017-04-15 11:53:32',
  'post_content' => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."

',
  'post_title' => 'Avenger',
  'post_excerpt' => '',
  'post_name' => 'avenger',
  'post_modified' => '2019-11-04 21:11:23',
  'post_modified_gmt' => '2019-11-04 21:11:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?post_type=product&#038;p=2713',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1494504995:216',
    '_edit_last' => '216',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"o8d6049\\"}],\\"styling\\":[],\\"element_id\\":\\"kpyl201\\"}]',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '2719',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7.jpg',
    '_yoast_wpseo_content_score' => '30',
    '_regular_price' => '30.90',
    'total_sales' => '1',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock' => NULL,
    '_stock_status' => 'instock',
    '_product_version' => '3.7.1',
    '_price' => '30.90',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/05/album-7.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2717,
  'post_date' => '2017-04-11 11:55:22',
  'post_date_gmt' => '2017-04-11 11:55:22',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.',
  'post_title' => 'Odesza In Return',
  'post_excerpt' => '',
  'post_name' => 'odesza-in-return',
  'post_modified' => '2017-05-11 11:58:14',
  'post_modified_gmt' => '2017-05-11 11:58:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?post_type=product&#038;p=2717',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1494504995:216',
    '_edit_last' => '216',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"wwuc733\\"}],\\"styling\\":[],\\"element_id\\":\\"ai1i001\\"}]',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '2714',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6.jpg',
    '_yoast_wpseo_content_score' => '30',
    '_regular_price' => '25.50',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock' => NULL,
    '_stock_status' => 'instock',
    '_product_version' => '3.0.0',
    '_price' => '25.50',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-6.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2569,
  'post_date' => '2017-03-10 12:46:33',
  'post_date_gmt' => '2017-03-10 12:46:33',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<!--themify_builder_static--><ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2569-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> </ol><!--/themify_builder_static-->',
  'post_title' => 'Black Beatles',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  'post_name' => 'black-beatles',
  'post_modified' => '2019-12-01 21:14:25',
  'post_modified_gmt' => '2019-12-01 21:14:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?post_type=product&#038;p=2569',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1494503456:216',
    '_edit_last' => '216',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '25.90',
    '_price' => '25.90',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_stock' => NULL,
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.8.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_review_count' => '0',
    '_wc_average_rating' => '0',
    '_tax_status' => 'taxable',
    '_default_attributes' => 
    array (
    ),
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_thumbnail_id' => '2708',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1.jpg',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"shadow\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"y4tw701\\"}},\\"styling\\":[],\\"element_id\\":\\"743h740\\"}],\\"styling\\":[],\\"element_id\\":\\"y9pr400\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"8z6e401\\"}],\\"styling\\":[],\\"element_id\\":\\"3khd478\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-1.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2568,
  'post_date' => '2017-03-10 02:41:45',
  'post_date_gmt' => '2017-03-10 02:41:45',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.

Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.<!--themify_builder_static--><ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2568-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> </ol><!--/themify_builder_static-->',
  'post_title' => 'Under the Iron Sea',
  'post_excerpt' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.',
  'post_name' => 'under-the-iron-sea',
  'post_modified' => '2019-10-26 03:13:45',
  'post_modified_gmt' => '2019-10-26 03:13:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?post_type=product&#038;p=2568',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1494503456:216',
    '_edit_last' => '216',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '26.90',
    '_price' => '26.90',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_stock' => NULL,
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.0.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_tax_status' => 'taxable',
    '_default_attributes' => 
    array (
    ),
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_thumbnail_id' => '2710',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"shadow\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"bki1074\\"}},\\"styling\\":[],\\"element_id\\":\\"huvm405\\"}],\\"styling\\":[],\\"element_id\\":\\"xt17444\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"pdpv005\\"}],\\"styling\\":[],\\"element_id\\":\\"09bj445\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-2.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2567,
  'post_date' => '2017-03-09 12:40:14',
  'post_date_gmt' => '2017-03-09 12:40:14',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.<!--themify_builder_static--><ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2567-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> </ol><!--/themify_builder_static-->',
  'post_title' => 'Mars',
  'post_excerpt' => 'Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur.',
  'post_name' => 'mars',
  'post_modified' => '2019-10-22 17:26:05',
  'post_modified_gmt' => '2019-10-22 17:26:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?post_type=product&#038;p=2567',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1494503458:216',
    '_edit_last' => '216',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '2711',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-mars.jpg',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '26.00',
    '_price' => '26.00',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_stock' => NULL,
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.6.5',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_review_count' => '0',
    '_wc_average_rating' => '0',
    '_tax_status' => 'taxable',
    '_default_attributes' => 
    array (
    ),
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"shadow\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"n6l6650\\"}},\\"styling\\":[],\\"element_id\\":\\"2qnx852\\"}],\\"styling\\":[],\\"element_id\\":\\"jq98028\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"dwu3092\\"}],\\"styling\\":[],\\"element_id\\":\\"hzao646\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-mars.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2562,
  'post_date' => '2017-03-08 12:38:06',
  'post_date_gmt' => '2017-03-08 12:38:06',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.<!--themify_builder_static--><ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2562-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> </ol><!--/themify_builder_static-->',
  'post_title' => 'Quiet Night Time',
  'post_excerpt' => 'Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.',
  'post_name' => 'quiet-night-time',
  'post_modified' => '2019-10-22 13:19:33',
  'post_modified_gmt' => '2019-10-22 13:19:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?post_type=product&#038;p=2562',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1494503454:216',
    '_edit_last' => '216',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '2712',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '27.00',
    '_price' => '27.00',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_stock' => NULL,
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.0.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_review_count' => '0',
    '_wc_average_rating' => '0',
    '_tax_status' => 'taxable',
    '_default_attributes' => 
    array (
    ),
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-4-1.jpg',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"shadow\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"yg04101\\"}},\\"styling\\":[],\\"element_id\\":\\"h47q555\\"}],\\"styling\\":[],\\"element_id\\":\\"n087050\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"s0by001\\"}],\\"styling\\":[],\\"element_id\\":\\"sx1x055\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-4-1.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2667,
  'post_date' => '2017-03-08 11:33:30',
  'post_date_gmt' => '2017-03-08 11:33:30',
  'post_content' => 'Donec porttitor luctus mi a tristique. Vivamus tempus pretium dui, eget efficitur eros facilisis id. Vestibulum eget libero vitae nulla pretium porttitor ac vitae ipsum. Sed ac aliquam turpis. Nullam tellus enim, convallis ac neque id, dignissim tincidunt ligula. Proin tincidunt viverra maximus. Pellentesque eu sapien sapien. In nec felis id velit laoreet dapibus at varius metus. Vestibulum quis luctus odio. Praesent tristique convallis consequat. Fusce lacinia ante eu nunc lobortis aliquam.

Ut imperdiet metus eu augue scelerisque ultricies. Ut turpis turpis, sodales ac lacus quis, tincidunt tristique nisi. Pellentesque ac porta quam, nec varius nisi. Sed vitae condimentum enim. Suspendisse scelerisque ligula gravida massa pretium facilisis sed sit amet neque. Integer dictum mollis pulvinar. In egestas ligula urna, quis vulputate magna blandit vel.<!--themify_builder_static--><ol> <li itemprop="track" itemscope="" itemtype="https://schema.org/MusicRecording"> <a href="#" itemprop="url">I\'ve Not Over Yet</a> <audio id="audio-2667-1" preload="none" style="width: 100%;" controls="controls"><source type="audio/mpeg" src="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3?_=1" /><a href="https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3">https://themify.me/demo/themes/shoppe-music/files/2017/03/myuu-ItsNotOverYet.mp3</a></audio> </li> </ol><!--/themify_builder_static-->',
  'post_title' => 'Insurgency EP',
  'post_excerpt' => 'Sed eget tincidunt nulla, posuere elementum ligula.
Nulla facilisi. Praesent luctus, neque dictum feugiat maxim Suspendisse congue imperdiet sem vitae dapibus.',
  'post_name' => 'insurgency-ep',
  'post_modified' => '2019-11-21 10:02:48',
  'post_modified_gmt' => '2019-11-21 10:02:48',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?post_type=product&#038;p=2667',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_edit_lock' => '1494503722:216',
    '_edit_last' => '216',
    '_visibility' => 'visible',
    '_stock_status' => 'instock',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    'total_sales' => '0',
    '_downloadable' => 'no',
    '_virtual' => 'no',
    '_featured' => 'no',
    '_product_attributes' => 
    array (
    ),
    '_regular_price' => '1288.00',
    '_sale_price' => '1000.00',
    '_price' => '1000.00',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_stock' => NULL,
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_product_version' => '3.8.0',
    '_yoast_wpseo_content_score' => '30',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_review_count' => '1',
    '_wc_average_rating' => '0',
    '_thumbnail_id' => '2715',
    '_tax_status' => 'taxable',
    '_default_attributes' => 
    array (
    ),
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":{\\"1\\":{\\"mod_name\\":\\"audio\\",\\"mod_settings\\":{\\"music_playlist\\":[{\\"audio_name\\":\\"I\\\'ve Not Over Yet\\",\\"audio_url\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/shoppe-music\\\\/files\\\\/2017\\\\/03\\\\/myuu-ItsNotOverYet.mp3\\"}],\\"hide_download_audio\\":\\"yes\\",\\"add_css_audio\\":\\"shadow\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"20\\",\\"padding_right\\":\\"30\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"20\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"checkbox_border_apply_all_border\\":\\"border\\",\\"custom_parallax_scroll_reverse_reverse\\":\\"reverse\\",\\"custom_parallax_scroll_fade_fade\\":\\"fade\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"},\\"element_id\\":\\"pll2110\\"}},\\"styling\\":[],\\"element_id\\":\\"5d1n100\\"}],\\"styling\\":[],\\"element_id\\":\\"cozh001\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"tqzq000\\"}],\\"styling\\":[],\\"element_id\\":\\"cbyi808\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/03/album-5.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2718,
  'post_date' => '2017-03-01 12:11:40',
  'post_date_gmt' => '2017-03-01 12:11:40',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?

Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. ',
  'post_title' => 'Unplugged',
  'post_excerpt' => '',
  'post_name' => 'unplugged',
  'post_modified' => '2019-10-09 05:41:02',
  'post_modified_gmt' => '2019-10-09 05:41:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shoppe-music/?post_type=product&#038;p=2718',
  'menu_order' => 0,
  'post_type' => 'product',
  'meta_input' => 
  array (
    '_wc_review_count' => '0',
    '_wc_rating_count' => 
    array (
    ),
    '_wc_average_rating' => '0',
    '_edit_lock' => '1494504995:216',
    '_edit_last' => '216',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"fpgm390\\"}],\\"styling\\":[],\\"element_id\\":\\"qmir179\\"}]',
    'content_width' => 'default_width',
    'builder_switch_frontend' => '0',
    '_thumbnail_id' => '2720',
    'post_image' => 'https://themify.me/demo/themes/shoppe-music/files/2017/05/album-8.jpg',
    '_yoast_wpseo_content_score' => '30',
    '_regular_price' => '29.50',
    '_sale_price' => '26.50',
    'total_sales' => '0',
    '_tax_status' => 'taxable',
    '_manage_stock' => 'no',
    '_backorders' => 'no',
    '_sold_individually' => 'no',
    '_upsell_ids' => 
    array (
    ),
    '_crosssell_ids' => 
    array (
    ),
    '_default_attributes' => 
    array (
    ),
    '_virtual' => 'no',
    '_downloadable' => 'no',
    '_download_limit' => '-1',
    '_download_expiry' => '-1',
    '_stock' => NULL,
    '_stock_status' => 'instock',
    '_product_version' => '3.6.5',
    '_price' => '26.50',
  ),
  'tax_input' => 
  array (
    'product_type' => 'simple',
  ),
  'thumb' => 'https://themify.me/demo/themes/shoppe-music/files/2017/05/album-8.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2603,
  'post_date' => '2017-03-14 06:14:25',
  'post_date_gmt' => '2017-03-14 06:14:25',
  'post_content' => '',
  'post_title' => 'Order Status',
  'post_excerpt' => '',
  'post_name' => 'order-status-2',
  'post_modified' => '2017-03-14 06:14:25',
  'post_modified_gmt' => '2017-03-14 06:14:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2603',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2603',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-support-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2602,
  'post_date' => '2017-03-14 06:14:25',
  'post_date_gmt' => '2017-03-14 06:14:25',
  'post_content' => '',
  'post_title' => 'Orders & Payments',
  'post_excerpt' => '',
  'post_name' => 'orders-payments',
  'post_modified' => '2017-03-14 06:14:25',
  'post_modified_gmt' => '2017-03-14 06:14:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2602',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2602',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/demo/themes/shopmusic/my-account/orders/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-support-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2604,
  'post_date' => '2017-03-14 06:14:25',
  'post_date_gmt' => '2017-03-14 06:14:25',
  'post_content' => '',
  'post_title' => 'Returns & Exchanges',
  'post_excerpt' => '',
  'post_name' => 'returns-exchanges',
  'post_modified' => '2017-03-14 06:14:25',
  'post_modified_gmt' => '2017-03-14 06:14:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2604',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2604',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-support-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2605,
  'post_date' => '2017-03-14 06:14:25',
  'post_date_gmt' => '2017-03-14 06:14:25',
  'post_content' => '',
  'post_title' => 'FAQ',
  'post_excerpt' => '',
  'post_name' => 'faq',
  'post_modified' => '2017-03-14 06:14:25',
  'post_modified_gmt' => '2017-03-14 06:14:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2605',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2605',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => '#',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-support-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2585,
  'post_date' => '2017-03-10 13:11:24',
  'post_date_gmt' => '2017-03-10 13:11:24',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '2585',
  'post_modified' => '2017-03-10 13:11:24',
  'post_modified_gmt' => '2017-03-10 13:11:24',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2585',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2583',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_icon' => 'ti-user',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'icon-menu',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2597,
  'post_date' => '2017-03-10 13:24:23',
  'post_date_gmt' => '2017-03-10 13:24:23',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '2597',
  'post_modified' => '2017-03-10 13:25:01',
  'post_modified_gmt' => '2017-03-10 13:25:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2597',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2580',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2596,
  'post_date' => '2017-03-10 13:24:23',
  'post_date_gmt' => '2017-03-10 13:24:23',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '2596',
  'post_modified' => '2017-03-10 13:25:01',
  'post_modified_gmt' => '2017-03-10 13:25:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2596',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2588',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2595,
  'post_date' => '2017-03-10 13:24:23',
  'post_date_gmt' => '2017-03-10 13:24:23',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '2595',
  'post_modified' => '2017-03-10 13:25:01',
  'post_modified_gmt' => '2017-03-10 13:25:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2595',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2590',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2594,
  'post_date' => '2017-03-10 13:24:23',
  'post_date_gmt' => '2017-03-10 13:24:23',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '2594',
  'post_modified' => '2017-03-10 13:25:01',
  'post_modified_gmt' => '2017-03-10 13:25:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/shopmusic/?p=2594',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '2592',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );



function themify_import_get_term_id_from_slug( $slug ) {
	$menu = get_term_by( "slug", $slug, "nav_menu" );
	return is_wp_error( $menu ) ? 0 : (int) $menu->term_id;
}

	$widgets = get_option( "widget_nav_menu" );
$widgets[1002] = array (
  'title' => 'Support',
  'nav_menu' => themify_import_get_term_id_from_slug( "" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_woocommerce_product_categories" );
$widgets[1003] = array (
  'title' => 'Categories',
  'orderby' => 'name',
  'dropdown' => 0,
  'count' => 0,
  'hierarchical' => 1,
  'show_children_only' => 0,
  'hide_empty' => 0,
);
update_option( "widget_woocommerce_product_categories", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1004] = array (
  'title' => '',
  'text' => 'Shoppe is a powerful shop theme created by Themify. It’s powered by WooCommerce and is highly customizable.

[themify_button link="https://themify.me/themes/shoppe" style="small outline black rect"]Download[/themify_button]',
  'filter' => true,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1006] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_search" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1008] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1009] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1010] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_nav_menu" );
$widgets[1011] = array (
  'nav_menu' => themify_import_get_term_id_from_slug( "footer-support-menu" ),
);
update_option( "widget_nav_menu", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1012] = array (
  'title' => 'Search',
  'text' => '[searchandfilter id="sidebar_filter"]',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1013] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => 'on',
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1014] = array (
  'title' => '',
  'text' => '<div class="payment-method">
<span><i class="fa fa-cc-visa"></i></span>
<span><i class="fa fa-cc-mastercard"></i></span>
<span><i class="fa fa-cc-paypal"></i></span>
</div>',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-layout-parts" );
$widgets[1015] = array (
  'title' => '',
  'layout_part' => 'optin-form',
);
update_option( "widget_themify-layout-parts", $widgets );



$sidebars_widgets = array (
  'footer-widget-4' => 
  array (
    0 => 'nav_menu-1002',
  ),
  'wp_inactive_widgets' => 
  array (
    0 => 'woocommerce_product_categories-1003',
    1 => 'text-1004',
    2 => 'archives-1005',
    3 => 'meta-1006',
    4 => 'search-1007',
    5 => 'categories-1008',
    6 => 'recent-posts-1009',
    7 => 'recent-comments-1010',
  ),
  'below-logo-widget' => 
  array (
    0 => 'nav_menu-1011',
  ),
  'sidebar-shop' => 
  array (
    0 => 'text-1012',
  ),
  'footer-widget-1' => 
  array (
    0 => 'themify-social-links-1013',
  ),
  'footer-widget-2' => 
  array (
    0 => 'text-1014',
  ),
  'footer-widget-3' => 
  array (
    0 => 'themify-layout-parts-1015',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-search_post_type' => 'all',
  'setting-webfonts_list' => 'recommended',
  'setting-default_layout' => 'sidebar-none',
  'setting-default_post_layout' => 'grid4',
  'setting-post_content_layout' => 'polaroid',
  'setting-post_masonry' => 'no',
  'setting-post_gutter' => 'gutter',
  'setting-default_layout_display' => 'excerpt',
  'setting-default_more_text' => 'Read More',
  'setting-excerpt_more' => '1',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_post_meta' => 'yes',
  'setting-default_post_date' => 'no',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar-none',
  'setting-default_page_single_media_position' => 'above',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-image_post_single_width' => '1160',
  'setting-image_post_single_height' => '550',
  'setting-search-result_layout' => 'sidebar1',
  'setting-search-result_post_layout' => 'list-post',
  'setting-search-result_layout_display' => 'content',
  'setting-search-result_media_position' => 'above',
  'setting-default_page_layout' => 'sidebar-none',
  'setting-customizer_responsive_design_tablet_landscape' => '1024',
  'setting-customizer_responsive_design_tablet' => '716',
  'setting-customizer_responsive_design_mobile' => '414',
  'setting-mobile_menu_trigger_point' => '1000',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-cache_gzip' => 'on',
  'setting-header_design' => 'header-logo-left',
  'setting-exclude_site_tagline' => 'on',
  'setting-footer_design' => 'footer-block',
  'setting-exclude_footer_site_logo' => 'on',
  'setting-exclude_footer_back' => 'on',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-mega_menu_posts' => '5',
  'setting-mega_menu_image_width' => '180',
  'setting-mega_menu_image_height' => '120',
  'setting-mega_menu_post_count' => 'off',
  'setting-imagefilter_applyto' => 'featuredonly',
  'setting-more_posts' => 'infinite',
  'setting-entries_nav' => 'numbered',
  'settings-footer_banner_twitter_username' => '@themify',
  'settings-footer_banner_twitter_link' => 'https://twitter.com/themify',
  'settings-footer_banner_twitter_image' => 'https://themify.me/demo/themes/shoppe/files/2016/11/footer-share-twitter.jpg',
  'settings-footer_banner_facebook_username' => 'Themify',
  'settings-footer_banner_facebook_link' => 'https://www.facebook.com/themify',
  'settings-footer_banner_facebook_image' => 'https://themify.me/demo/themes/shoppe/files/2016/11/footer-share-facebook.jpg',
  'settings-footer_banner_pinterest_username' => 'Themify',
  'settings-footer_banner_pinterest_link' => 'https://www.pinterest.com/',
  'settings-footer_banner_pinterest_image' => 'https://themify.me/demo/themes/shoppe/files/2016/11/footer-share-pinterest.jpg',
  'setting-footer_text_left' => '© 2017 Shoppe Music. All Rights Reserved',
  'setting-footer_text_right_hide' => 'hide',
  'setting-shop_layout' => 'sidebar-none',
  'setting-shop_archive_layout' => 'sidebar-none',
  'setting-products_layout' => 'grid4',
  'setting-shop_masonry_disabled' => 'on',
  'setting-product_post_gutter' => 'gutter',
  'setting-products_slider' => 'enable',
  'setting-shop_products_per_page' => '9',
  'setting-hide_shop_count' => 'on',
  'setting-hide_shop_sorting' => 'on',
  'setting-hide_shop_title' => 'on',
  'setting-default_product_index_image_post_width' => '262',
  'setting-default_product_index_image_post_height' => '262',
  'setting-single_product_layout' => 'sidebar-none',
  'setting-product_image_layout' => 'img-left',
  'setting-default_product_single_image_post_width' => '500',
  'setting-default_product_single_image_post_height' => '500',
  'setting-product_gallery_type' => 'zoom',
  'setting-related_products_limit' => '3',
  'setting-product_description_type' => 'long',
  'setting-wishlist_page' => '2702',
  'setting-cart_style' => 'dropdown',
  'setting-cart_show_seconds' => '1000',
  'setting-spark_color' => '#a86fbb',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/shoppe/wp-content/themes/themify-shoppe/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/shoppe/wp-content/themes/themify-shoppe/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/shoppe/wp-content/themes/themify-shoppe/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/shoppe/wp-content/themes/themify-shoppe/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/shoppe/wp-content/themes/themify-shoppe/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_link_themify-link-6' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-6' => 'ti-facebook',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_link_themify-link-5' => 'https://twitter.com/themify',
  'setting-link_ficon_themify-link-5' => 'ti-twitter',
  'setting-link_type_themify-link-10' => 'font-icon',
  'setting-link_title_themify-link-10' => 'Instagram',
  'setting-link_link_themify-link-10' => '#',
  'setting-link_ficon_themify-link-10' => 'fa-instagram',
  'setting-link_type_themify-link-9' => 'font-icon',
  'setting-link_title_themify-link-9' => 'Pinterest',
  'setting-link_link_themify-link-9' => 'https://www.pinterest.com',
  'setting-link_ficon_themify-link-9' => 'ti-pinterest',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'YouTube',
  'setting-link_link_themify-link-8' => 'https://www.youtube.com/user/themifyme/',
  'setting-link_ficon_themify-link-8' => 'ti-youtube',
  'setting-link_type_themify-link-11' => 'font-icon',
  'setting-link_title_themify-link-11' => 'Google Plus',
  'setting-link_link_themify-link-11' => '#',
  'setting-link_ficon_themify-link-11' => 'ti-google',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-5":"themify-link-5","themify-link-10":"themify-link-10","themify-link-9":"themify-link-9","themify-link-8":"themify-link-8","themify-link-11":"themify-link-11"}',
  'setting-link_field_hash' => '12',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'setting-page_builder_cache' => 'on',
  'setting-page_builder_expiry' => '2',
  'skin' => 'music',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
$menu = get_terms( "nav_menu", array( "slug" => "icon-menu" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["icon-menu"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
themify_do_demo_import();